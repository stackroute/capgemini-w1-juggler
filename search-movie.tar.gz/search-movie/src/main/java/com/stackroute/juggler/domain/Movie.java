package com.stackroute.juggler.domain;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;

public class Movie {
	@Id
	private int movieId;
	private String movieTitle;
	private String moviePoster;
	private String movieDescription;
	private String movieReleasedate;
	private String movieDuration;
	private String movieLanguage;
	private String movieGenre;
	private String movieFormat;
	private String movieHero;
	private String movieHeroine;
	private String movieDirector;
	
	public Movie(int movieId, String movieTitle, String moviePoster, String movieDescription, String movieReleasedate,
			String movieDuration, String movieLanguage, String movieGenre, String movieFormat, String movieHero,
			String movieHeroine, String movieDirector) {
		super();
		this.movieId = movieId;
		this.movieTitle = movieTitle;
		this.moviePoster = moviePoster;
		this.movieDescription = movieDescription;
		this.movieReleasedate = movieReleasedate;
		this.movieDuration = movieDuration;
		this.movieLanguage = movieLanguage;
		this.movieGenre = movieGenre;
		this.movieFormat = movieFormat;
		this.movieHero = movieHero;
		this.movieHeroine = movieHeroine;
		this.movieDirector = movieDirector;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public String getMoviePoster() {
		return moviePoster;
	}

	public void setMoviePoster(String moviePoster) {
		this.moviePoster = moviePoster;
	}

	public String getMovieDescription() {
		return movieDescription;
	}

	public void setMovieDescription(String movieDescription) {
		this.movieDescription = movieDescription;
	}

	public String getMovieReleasedate() {
		return movieReleasedate;
	}

	public void setMovieReleasedate(String movieReleasedate) {
		this.movieReleasedate = movieReleasedate;
	}

	public String getMovieDuration() {
		return movieDuration;
	}

	public void setMovieDuration(String movieDuration) {
		this.movieDuration = movieDuration;
	}

	public String getMovieLanguage() {
		return movieLanguage;
	}

	public void setMovieLanguage(String movieLanguage) {
		this.movieLanguage = movieLanguage;
	}

	public String getMovieGenre() {
		return movieGenre;
	}

	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}

	public String getMovieFormat() {
		return movieFormat;
	}

	public void setMovieFormat(String movieFormat) {
		this.movieFormat = movieFormat;
	}

	public String getMovieHero() {
		return movieHero;
	}

	public void setMovieHero(String movieHero) {
		this.movieHero = movieHero;
	}

	public String getMovieHeroine() {
		return movieHeroine;
	}

	public void setMovieHeroine(String movieHeroine) {
		this.movieHeroine = movieHeroine;
	}

	public String getMovieDirector() {
		return movieDirector;
	}

	public void setMovieDirector(String movieDirector) {
		this.movieDirector = movieDirector;
	}
	
	


}
