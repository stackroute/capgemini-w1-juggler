export class User {
    userName: string;
    emailId: string;
    mobileNo: number;
    password: string;
    gender: string;
    language: string;
    dateOfBirth: string;
    location: string;
    genre: string;
    likes: string;
}
