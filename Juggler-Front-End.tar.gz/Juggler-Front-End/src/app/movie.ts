export class Movie {
    movieId: number;
    movieTitle: string;
    poster: string;
    description: string;
    language: string;
    genre: string;
    cast: string;
    releaseDate: string;
    duration: string;
}
