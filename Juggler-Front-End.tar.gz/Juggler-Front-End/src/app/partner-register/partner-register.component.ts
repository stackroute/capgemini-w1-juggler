import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partner-register',
  templateUrl: './partner-register.component.html',
  styleUrls: ['./partner-register.component.scss']
})
export class PartnerRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
